=====
Usage
=====

To use collector in a project::

    import collector
