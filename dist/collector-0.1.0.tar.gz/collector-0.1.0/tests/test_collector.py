#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_collector
----------------------------------

Tests for `collector` module.
"""


import sys
import unittest

from collector import collector



class TestCollector(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_000_something(self):
        pass



if __name__ == '__main__':
    sys.exit(unittest.main())
